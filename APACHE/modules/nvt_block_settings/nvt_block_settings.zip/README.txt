BLOCK BACKGROUND
-----------
Project URL: http://www.thanhtuandev.com

=====
Installation
-----

1. Enable the module
2. Visit the block configuration page at Administration -> Structure -> Block Layout
and click on the Configure link for a block.
3. Updating...